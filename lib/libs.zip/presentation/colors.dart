import 'package:flutter/material.dart';

const Color wColor = Colors.white;
const Color bCOlor = Colors.black;
const sdColor = Colors.black12;
const Color pColor = Color(0xFF0C84FF);
